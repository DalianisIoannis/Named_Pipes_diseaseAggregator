#include "./general.h"

int sendMessage(int, char*, int);
char* receiveMessage(int , char*, int);